# Start here

1. Open `university/v17-UNIVERSITY.html` (Chrome/Safari).
2. Search and browse 240 sections.
3. Optional heavy file: `university/v16-TRANSCEND.html`.
4. Future projects: `prompts/` (three independent labs).
5. Hermes later: `hermes/HOW-TO-WIRE-HERMES.md`.

| Audience | Send |
|---|---|
| Friends / learners | `zips/v17-UNIVERSITY.html.zip` or complete pack |
| Power users | also full-archive-optional |
| You | entire `UC-LAB-FREE-SHARE` folder |

v16 + v17 live here. Older Desktop clutter cleaned separately.
