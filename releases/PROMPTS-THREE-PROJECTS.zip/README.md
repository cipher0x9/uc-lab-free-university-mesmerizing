# UC Lab Free Share Pack

**Free for learning and sharing.** Clean branding — a lifetime UC/CC university plus future prompt labs.

## What’s inside

| Path | What |
|---|---|
| `university/v17-UNIVERSITY.html` | **Best for everyone** (~3.6 MB) — 240 curriculum sections, themes, search, offline |
| `university/v16-TRANSCEND.html` | Full v16 (~345 MB) — richer embedded libraries; strong machine recommended |
| `university/full-archive-optional/` | Optional compressed huge v17 archive (for power users) |
| `prompts/01-languages-mastery/` | 9–10 language mastery prompt system |
| `prompts/02-ai-ml-future-lab/` | AI/ML/future tools + Mac Mini lab prompts (deep) |
| `prompts/03-agentic-nature-remote/` | One-person agentic AI + nature-remote living OS |
| `hermes/` | How to wire Hermes later for auto-enrichment |
| `zips/` | Ready-to-share zip files |

## Can I share large files as zip?

**Yes.** Zip is a normal, correct way to share. The only problem with the old **~760 MB HTML** was that **web browsers struggle to open** a single file that big — not that zip is forbidden.

- **Share freely:** `zips/v17-UNIVERSITY.html.zip` or complete pack zip  
- **Optional archive:** full-archive-optional (large, for you / power users)

## Open

```bash
open university/v17-UNIVERSITY.html
```

Themes: Warm · Night · Cobalt · Forest · Aurora · Sunset  
`Cmd/Ctrl+K` search · mark studied · focus mode · random section

## Share freely for education

No warranty. Pin vendor docs before production. Lab safely.
